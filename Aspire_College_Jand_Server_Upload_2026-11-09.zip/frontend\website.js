const menuButton = document.querySelector('.menu');
const navigation = document.querySelector('.navlinks');
if (menuButton && navigation) {
  menuButton.addEventListener('click', () => {
    const open = navigation.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
  });
  navigation.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    navigation.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  }));
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    navigation.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  });
}

// Keep the supplied banner visible even when the database is unavailable.
async function loadSchoolBanners() {
  try {
    const response = await fetch('/api/banners');
    if (!response.ok) return;
    const data = await response.json();
    const banners = (Array.isArray(data.banners) ? data.banners : [])
      .filter(banner => banner.isActive !== false && banner.imageUrl);
    const container = document.querySelector('.additional-banners');
    if (!container) return;
    for (const banner of banners) {
      const url = new URL(banner.imageUrl, window.location.origin);
      if (!['http:', 'https:'].includes(url.protocol)) continue;
      const img = document.createElement('img');
      img.src = url.href;
      img.alt = banner.title || 'Aspire Group of Colleges announcement';
      img.loading = 'lazy';
      img.addEventListener('error', () => img.remove());
      container.append(img);
    }
  } catch (_) { /* Static school content remains available offline. */ }
}
loadSchoolBanners();

const enquiryForm = document.querySelector('.enquiry-form');
if (enquiryForm) {
  enquiryForm.addEventListener('submit', event => {
    event.preventDefault();
    const note = enquiryForm.querySelector('.form-note');
    if (note) note.textContent = 'Thank you — our admission team will contact you shortly.';
    enquiryForm.reset();
  });
}
